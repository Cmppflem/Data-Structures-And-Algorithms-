import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;	


public class Start 
{
	private static Scanner input = new Scanner(System.in);
	private static ArrayList<String> regionlist = new ArrayList<String>();	
	private static ArrayList<String> filmnames = new ArrayList<String>();
	private static ArrayList<String> partial = new ArrayList<String>();
	private static ArrayList<String> nconstPerson = new ArrayList<String>();
	private static ArrayList<String> nconstFilm = new ArrayList<String>();
	private static ArrayList<String> nconstMax = new ArrayList<String>();
	private static ArrayList<String> nconstCategory = new ArrayList<String>();
	
	public static void main(String[] args) throws FileNotFoundException 
		{
			ArrayList<FilmData> film = readFile("SampleDataset-FilmTitle.csv");
			ArrayList<PersonData> person = readFilePerson("SampleDataset-Person.csv");
				
			Menu(film, person);
		}
	
	public static void Menu(ArrayList<FilmData> film, ArrayList<PersonData> person) 
		{
			String choice = "";
			
			do {
				System.out.println("\n -- Main Menu --");
				System.out.println("1 - List All Regions Which Have Data.");
				System.out.println("2 - Display Film Names For A Specified Region.");
				System.out.println("3 - Search For A Film Title And Display All Possible Titles And Their Regions.");
				System.out.println("4 - Display The Name Of A Film And The Category Of Contribition For Any Specified Person.");
				System.out.println("5 - Display The Names And Category Of Contribution For All People Who Worked On A Specified Film. ");
				System.out.println("6 - Find The Person With The Highest Number Of Credits To Their Name And Display The Films They Have Been Associated With.");
				System.out.println("7 - Find The Person With The Highest Number Of Credits For A Specified Category And Display The Films Associated.");
				System.out.println("Q - Quit");
				
				choice = input.nextLine().toUpperCase();
				switch (choice)
				
				{
				case "1" : 
				{
					FilmRegion(film);
					break;
				}
				case "2" : 
				{
					FilmNames(film);
					break;
				}
				case "3" : 
				{
					FilmPartial(film);
					break;
				}
				case "4" : 
				{
					nConstPerson(film, person);
					break;
				}
				case "5" : 
				{
					nConstFilm(film, person);
					break;
				}
				case "6" : 
				{
					nConstMax(person, film);
					break;
				}
				case "7" : 
				{
					nConstCategory(person, film);
					break;
				}
				}
			} 
			while (!choice.equals("Q"));
					outputFilms(film);
					System.out.println("--GOODBYE--");
		}

	private static String percent(int num, int div)
		{
			double perc = ((double)num / div);
			perc *= 100;
			return String.format(" %.1f%%", perc);
		}

	public static ArrayList<FilmData> readFile(String filename) throws FileNotFoundException 
		{
			ArrayList<FilmData> films = new ArrayList<>();
			File csvFile = new File(filename);
			Scanner csvScan = new Scanner(csvFile);
			//csvScan.nextLine(); // read header
				while (csvScan.hasNextLine()) 
				{
					String line = csvScan.nextLine();
					FilmData film = new FilmData(line);
					films.add(film);
				}
			csvScan.close();
			return films;
		}

	public static ArrayList<PersonData> readFilePerson (String filename) throws FileNotFoundException 
	{
		ArrayList<PersonData> persons = new ArrayList<>();
		File csvFile = new File(filename);
		Scanner csvScan = new Scanner(csvFile);
		//csvScan.nextLine(); // read header
			while (csvScan.hasNextLine()) 
			{
				String line = csvScan.nextLine();
				PersonData person = new PersonData(line);
				persons.add(person);
			}
		csvScan.close();
		return persons;
	}

	private static void outputFilms(ArrayList<FilmData> film) 
		{
			int regionGB=0, originalTitle=0, neitherCrit=0;
			for (int i = 0; i < film.size(); i++) 
			{
				FilmData currentFilm = film.get(i);
				if (currentFilm != null) {
					if (currentFilm.region.startsWith("GB"))
						regionGB++;
					if (currentFilm.type.startsWith("original"))
						originalTitle++;
					if(!(currentFilm.region.startsWith("GB") || currentFilm.type.startsWith("original")))
						neitherCrit++;
					System.out.println(currentFilm.titleId+": ("+currentFilm.title+") ("+currentFilm.region + ") ("+currentFilm.isOriginalTitle + ")");
				}
			}
		System.out.println("There are " + film.size() + " recorded films; ");
		System.out.println(regionGB+" have their region set as GB - "+percent(regionGB, film.size()));
		System.out.println(originalTitle+" have an original title - "+percent(originalTitle, film.size()));
		System.out.println(neitherCrit+"have neither -"+percent(neitherCrit,film.size()));
	}

	private static void FilmRegion (ArrayList<FilmData> film) 
		{
			for (int i = 0; i < film.size(); i++ ) 
			{
				
				if (!regionlist.contains(film.get(i).region)&&!film.get(i).region.equals("\\N"))
				{
					regionlist.add(film.get(i).region);
				}
			}

		System.out.println(regionlist);
		}

	private static void FilmNames (ArrayList<FilmData> film) 
		{
		
		String answer = null;
		System.out.println("Please enter a specified region: ");
		answer = input.next();
		
			for (int i = 0; i < film.size(); i++ ) 
			{
			
				if (film.get(i).region.equals(answer))
				{
					filmnames.add(film.get(i).title);
				}
			}
			for (String names : filmnames) 
			{
				System.out.println(names);
			}
		}
	
	private static void FilmPartial (ArrayList<FilmData> film) 
		{
			String answerPart = null;
			System.out.println("Please enter film name: ");
			answerPart = input.next();
			
				for (int i = 0; i < film.size(); i++ ) 
				{
				
					if (film.get(i).title.contains(answerPart))
					{
						partial.add(film.get(i).title);
						partial.add(film.get(i).region);
					}
				}
				
				for (int i = 0; i < partial.size(); i+=2 ) 
				{
					System.out.println(partial.get(i)+", " + partial.get(i+1));
				}
		}
	
	private static void nConstPerson (ArrayList<FilmData> film, ArrayList<PersonData> person) 
		{
		
			String answerN = null;
			System.out.println("Please enter a specific nconst: ");
			answerN = input.next();
			
				for (int i = 0; i < person.size(); i++ ) 
				{
				
					if (person.get(i).nconst.contains(answerN))
					{
						for (int j = 0; j < film.size(); j++)
						{
							if (person.get(i).tconst.equals(film.get(j).titleId)) 
								{
									nconstPerson.add(film.get(j).title);
									nconstPerson.add(person.get(i).category);
								}
						}
					}
				}
		
		for (int i = 0; i < nconstPerson.size(); i+=2 ) 
			{
				System.out.println(nconstPerson.get(i)+", " + nconstPerson.get(i+1));
			}
		}
	
	private static void nConstFilm (ArrayList<FilmData> film, ArrayList<PersonData> person) 
	{
	
	String answerF = null;
	System.out.println("Please enter a Film Title: ");
	answerF = input.nextLine();
	
		for (int i = 0; i < film.size(); i++ ) 
		{
		
			if (film.get(i).title.contains(answerF))
			{
				for (int j = 0; j < person.size(); j++)
				{
					if (film.get(i).titleId.equals(person.get(j).tconst)) 
						{
							nconstFilm.add(person.get(j).nconst);
							nconstFilm.add(person.get(j).category);
						}
				}
			}
		}
		
		for (int i = 0; i < nconstFilm.size(); i+=2 ) 
		{
			System.out.println(nconstFilm.get(i)+", " + nconstFilm.get(i+1));
		}
	}
	
	private static void nConstMax (ArrayList<PersonData> person, ArrayList<FilmData> film) 
	{
	
	Comparator<PersonData> sort = null;
	
	sort = new Comparator<PersonData>() 
	{
			public int compare(PersonData o1, PersonData o2) 
			{
				return o1.nconst.compareTo(o2.nconst);
			}
			
	};	
		Collections.sort(person, sort);

		PersonData prev = person.get(0), mostCommon=null;
		int num = 0, max = 0;
		
		for (PersonData currentN:person)
		{
			
		  if (currentN.nconst.equals(prev.nconst)) 
		  {
			  num++;
		  } 
		  else 
		  {
		    if (num >= max) 
		    {
		    	max = num;
		    	mostCommon = prev;
		    }
			num = 1;
		  }
		  prev = currentN;
		}
		
		System.out.println("The Person With The Highest Number Of Credits To Their Name is: " +mostCommon.nconst);
		
		for (int i = 0; i < person.size(); i++ ) 
		{
			if (person.get(i).nconst.contains(mostCommon.nconst))
			{
				for (int j = 0; j < film.size(); j++)
				{
					if (person.get(i).tconst.equals(film.get(j).titleId)) 
						{
							nconstMax.add(film.get(j).title);
						}
				}
			}
		}
		
		System.out.println("The Films That They Have Been Associated With:");
		
		for (int i = 0; i < nconstMax.size(); i++ ) 
		{
			System.out.println(nconstMax.get(i));
		}
	}
	
	private static void nConstCategory (ArrayList<PersonData> person, ArrayList<FilmData> film) 
	{
	
	Comparator<PersonData> sort = null;
	
	sort = new Comparator<PersonData>() 
	{
			public int compare(PersonData o1, PersonData o2) 
			{
				return o1.nconst.compareTo(o2.nconst);
			}
	};	
		Collections.sort(person, sort);

		PersonData prev = person.get(0), mostCommon=null;
		int num = 0, max = 0;
		
		String answerC = null;
		System.out.println("Please enter a Category: ");
		answerC = input.nextLine();
		
		for (PersonData currentN:person)
		{
			
		  if (currentN.nconst.equals(prev.nconst) && (currentN.category.equals(answerC))) 
		  {
			  num++;
		  } 
		  else 
		  {
		    if (num >= max) 
		    {
		    	max = num;
		    	mostCommon = prev;
		    }
			num = 1;
		  }
		  prev = currentN;
		}
			System.out.println("The Person With The Highest Number Of Credits For That Cateorgy Is: " + mostCommon.nconst);
	
	for (int i = 0; i < person.size(); i++ ) 
	{
	
		if (person.get(i).nconst.contains(mostCommon.nconst))
		{
			for (int j = 0; j < film.size(); j++)
			{
				if (person.get(i).tconst.equals(film.get(j).titleId)) 
					{
						nconstCategory.add(film.get(j).title);
					}
			}
		}
	}
		for (int i = 0; i < nconstCategory.size(); i++ ) 
		{
			System.out.println(nconstCategory.get(i));
		}
	}
}
