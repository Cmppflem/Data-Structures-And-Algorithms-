import java.util.Arrays;

public class FilmData 
	{
		public final String SEP = ",";
		public String titleId;
		public String ordering;
		public String title; 
		public String region; 	
		public String language;
		public String type; 
		public String attributes;
		public String isOriginalTitle; 

public FilmData(String csvString) 
	{
		String[] csvParts = lineSplit(csvString, SEP);
		int idx = 0;
		titleId = csvParts[idx++];
		ordering = csvParts[idx++];
		title = csvParts[idx++];
		region = csvParts[idx++];
		language = csvParts[idx++];
		type = csvParts[idx++];
		attributes = csvParts[idx++];
		isOriginalTitle = csvParts[idx++];
	}
	
public String[] lineSplit(String csvString, String s)
	{
		int index = 0;
		int qouteCount = 0;
		String[] parts = new String[8];
		Arrays.fill(parts, "");
			
		for(int i = 0; i < csvString.length(); i++)
	{
			if(csvString.charAt(i) != ',') {
				parts[index] += csvString.charAt(i);
	}
			if(csvString.charAt(i) == '"')
	{
				qouteCount++;
	}
			if(csvString.charAt(i) == ',' && qouteCount%2 == 0)
				index++;
			if(csvString.charAt(i) == ',' && qouteCount%2 == 1)
				parts[index] += csvString.charAt(i);
	}
		return parts;
	}

public String toCSVString() 
	{
		return titleId+SEP+ordering+SEP+title+SEP+region+SEP+language+SEP+type+SEP+attributes+
				SEP+isOriginalTitle;
	}

}
