import java.util.Arrays;

public class PersonData {
	
	public final String SEP = ",";
	public String tconst;
	public String ordering;
	public String nconst; 
	public String category; 	
	public String job;
	public String characters; 
	
	public PersonData(String csvString) 
	{
		String[] csvParts = PersonlineSplit(csvString, SEP);
		int idx = 0;
		tconst = csvParts[idx++];
		ordering = csvParts[idx++];
		nconst = csvParts[idx++];
		category = csvParts[idx++];
		job = csvParts[idx++];
		characters = csvParts[idx++];
		
	}
	
	public String[] PersonlineSplit(String csvString, String s)
	{
		int index = 0;
		int qouteCount = 0;
		String[] parts = new String[8];
		Arrays.fill(parts, "");
			
		for(int i = 0; i < csvString.length(); i++)
	{
			if(csvString.charAt(i) != ',') {
				parts[index] += csvString.charAt(i);
	}
			if(csvString.charAt(i) == '"')
	{
				qouteCount++;
	}
			if(csvString.charAt(i) == ',' && qouteCount%2 == 0)
				index++;
			if(csvString.charAt(i) == ',' && qouteCount%2 == 1)
				parts[index] += csvString.charAt(i);
	}
		return parts;
	}
	public String toCSVString() 
	{
		return tconst+SEP+ordering+SEP+nconst+SEP+category+SEP+job+SEP+characters;
	}
}
